
import React from 'react';
import { BotIcon, SettingsIcon } from './Icons.tsx';
import { motion } from 'framer-motion';

interface HeaderProps {
  onSettingsClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onSettingsClick }) => {
  return (
    <header className="sticky top-0 z-10 bg-white/70 backdrop-blur-lg border-b border-slate-200/80">
      <div className="max-w-4xl mx-auto flex items-center justify-between p-4">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-gradient-to-br from-sky-500 to-blue-600 rounded-full flex items-center justify-center shadow-md">
            <BotIcon className="text-white w-7 h-7" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-800">Sradex AI Assistant</h1>
            <p className="text-sm text-slate-500">Powered by Gemini</p>
          </div>
        </div>
        <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={onSettingsClick} className="p-2 rounded-full text-slate-500 hover:bg-slate-200/70 hover:text-slate-800 transition-colors" aria-label="Settings">
          <SettingsIcon />
        </motion.button>
      </div>
    </header>
  );
};
