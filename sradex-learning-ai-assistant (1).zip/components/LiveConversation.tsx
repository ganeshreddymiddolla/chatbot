
import React, { useEffect, useState } from 'react';
import { EndCallIcon, MicrophoneIcon } from './Icons.tsx';
import { VoiceVisualizer } from './VoiceVisualizer.tsx';
import type { Message } from '../types.ts';
import { motion, AnimatePresence } from 'framer-motion';

interface LiveConversationProps {
  onExit: () => void;
  isListening: boolean;
  isSpeaking: boolean;
  startListening: () => void;
  stopListening: () => void;
  analyser: AnalyserNode | null;
  lastMessage: Message;
  error: string | null;
}

export const LiveConversation: React.FC<LiveConversationProps> = ({
  onExit,
  isListening,
  isSpeaking,
  startListening,
  stopListening,
  analyser,
  lastMessage,
  error
}) => {
  const [statusText, setStatusText] = useState("Initializing...");

  useEffect(() => {
    const timer = setTimeout(() => {
        startListening();
    }, 300);
    return () => clearTimeout(timer);
  }, [startListening]);

  useEffect(() => {
    if (error) {
      setStatusText("Microphone error. Please check permissions.");
    } else if (isListening) {
      setStatusText("Listening...");
    } else if (isSpeaking) {
      setStatusText("Thinking...");
    } else {
      setStatusText("Click the mic to speak");
    }
  }, [isListening, isSpeaking, error]);

  const handleMicClick = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-slate-900 z-50 flex flex-col items-center justify-center p-4 overflow-hidden"
    >
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(14,165,233,0.3),rgba(255,255,255,0))]"></div>

      <motion.button 
        initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0, transition: { delay: 0.5 } }}
        onClick={onExit} className="absolute top-5 right-5 p-3 rounded-full text-white/70 bg-white/10 hover:bg-white/20 transition-colors" aria-label="Exit live mode">
        <EndCallIcon />
      </motion.button>

      <div className="w-full max-w-4xl h-1/3 flex items-center justify-center">
        <VoiceVisualizer analyser={analyser} isSpeaking={isSpeaking} isListening={isListening} />
      </div>

      <div className="text-center text-white/90 text-2xl font-medium h-24 px-4 flex items-center justify-center">
        <AnimatePresence mode="wait">
          <motion.p 
            key={statusText}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={`line-clamp-2 ${error ? 'text-red-400' : ''}`}
          >
            {isSpeaking && lastMessage.role === 'model' ? lastMessage.text : statusText}
          </motion.p>
        </AnimatePresence>
      </div>
      {error && <p className="text-sm text-red-400/70 mt-1 max-w-md text-center">{error}</p>}

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0, transition: { delay: 0.5 } }} className="mt-8 relative">
        {isListening && <div className="absolute inset-0 rounded-full bg-sky-500/50 animate-ping -z-10"></div>}
        <motion.button
          whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
          onClick={handleMicClick}
          className={`relative w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300 text-white shadow-2xl ${isListening ? 'bg-red-500' : 'bg-sky-600 hover:bg-sky-700'}`}
          aria-label={isListening ? 'Stop listening' : 'Start listening'}
        >
          <MicrophoneIcon />
        </motion.button>
      </motion.div>
    </motion.div>
  );
};
