
import React, { useRef, useEffect } from 'react';

interface VoiceVisualizerProps {
  analyser: AnalyserNode | null;
  isSpeaking: boolean;
  isListening: boolean;
}

export const VoiceVisualizer: React.FC<VoiceVisualizerProps> = ({ analyser, isSpeaking, isListening }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameId = useRef<number>();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const canvasCtx = canvas.getContext('2d');
    if (!canvasCtx) return;

    const draw = (time: number) => {
      animationFrameId.current = requestAnimationFrame(draw);
      canvasCtx.clearRect(0, 0, canvas.width, canvas.height);
      
      if (isListening && analyser) {
        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        analyser.getByteTimeDomainData(dataArray);
        
        canvasCtx.lineWidth = 2;
        canvasCtx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
        canvasCtx.beginPath();

        const sliceWidth = canvas.width * 1.0 / bufferLength;
        let x = 0;

        for (let i = 0; i < bufferLength; i++) {
          const v = dataArray[i] / 128.0;
          const y = v * canvas.height / 2;

          if (i === 0) {
            canvasCtx.moveTo(x, y);
          } else {
            canvasCtx.lineTo(x, y);
          }
          x += sliceWidth;
        }
        canvasCtx.lineTo(canvas.width, canvas.height / 2);
        canvasCtx.stroke();

      } else if (isSpeaking) {
        const baseRadius = canvas.height / 4;
        const breath = Math.sin(time * 0.002) * 10;
        const fastPulse = Math.sin(time * 0.01) * 2;
        const radius = baseRadius + breath + fastPulse;

        const gradient = canvasCtx.createRadialGradient(canvas.width / 2, canvas.height / 2, radius * 0.5, canvas.width / 2, canvas.height / 2, radius);
        gradient.addColorStop(0, 'rgba(14, 165, 233, 0.6)');
        gradient.addColorStop(1, 'rgba(14, 165, 233, 0)');

        canvasCtx.beginPath();
        canvasCtx.arc(canvas.width / 2, canvas.height / 2, radius, 0, 2 * Math.PI);
        canvasCtx.fillStyle = gradient;
        canvasCtx.fill();

        canvasCtx.beginPath();
        canvasCtx.arc(canvas.width / 2, canvas.height / 2, radius - 2, 0, 2 * Math.PI);
        canvasCtx.strokeStyle = 'rgba(125, 211, 252, 0.5)';
        canvasCtx.lineWidth = 1;
        canvasCtx.stroke();
      }
    };

    draw(0);

    return () => {
      if (animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
    };
  }, [analyser, isSpeaking, isListening]);

  return <canvas ref={canvasRef} width="600" height="200" />;
};
