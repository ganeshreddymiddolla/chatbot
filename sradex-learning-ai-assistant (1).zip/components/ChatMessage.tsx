
import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import type { Message } from '../types.ts';
import { UserIcon, BotIcon, SpeakerIcon } from './Icons.tsx';
import { Sources } from './Sources.tsx';
import { motion } from 'framer-motion';

interface ChatMessageProps {
  message: Message;
  onSpeak: () => void;
  isStreaming?: boolean;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message, onSpeak, isStreaming }) => {
  const isUser = message.role === 'user';

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`flex items-start gap-4 ${isUser ? 'justify-end' : 'justify-start'}`}
    >
      {!isUser && (
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center shadow-sm">
          <BotIcon className="text-sky-600" />
        </div>
      )}
      <div className="max-w-xl flex flex-col">
        <div
          className={`rounded-xl px-4 py-3 shadow-md ${
            isUser
              ? 'bg-gradient-to-br from-sky-500 to-blue-600 text-white rounded-br-none'
              : 'bg-white text-slate-800 rounded-bl-none'
          }`}
        >
          <div className="prose prose-sm prose-slate max-w-none text-inherit prose-p:my-2 prose-headings:my-3 prose-a:text-blue-500 hover:prose-a:text-blue-600 prose-code:bg-slate-200 prose-code:text-slate-800 prose-code:rounded prose-code:p-1">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {message.text}
            </ReactMarkdown>
            {isStreaming && <motion.span initial={{opacity: 0}} animate={{opacity: [0, 1, 0]}} transition={{repeat: Infinity, duration: 1}} className="inline-block w-1 h-4 bg-slate-500 rounded-full ml-1"></motion.span>}
          </div>
           {!isUser && message.text && !isStreaming && (
            <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={onSpeak} className="mt-2 text-slate-400 hover:text-sky-600" aria-label="Read message aloud">
              <SpeakerIcon />
            </motion.button>
          )}
        </div>
        {message.sources && message.sources.length > 0 && (
          <Sources sources={message.sources} />
        )}
      </div>
      {isUser && (
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center shadow-sm">
          <UserIcon />
        </div>
      )}
    </motion.div>
  );
};
