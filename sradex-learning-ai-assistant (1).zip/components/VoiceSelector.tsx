
import React from 'react';
import { SpeakerIcon } from './Icons.tsx';

interface VoiceSelectorProps {
  voices: SpeechSynthesisVoice[];
  selectedVoiceURI: string;
  onChange: (voiceURI: string) => void;
  testSpeak: (text: string, voiceURI: string) => void;
}

export const VoiceSelector: React.FC<VoiceSelectorProps> = ({ voices, selectedVoiceURI, onChange, testSpeak }) => {
  if (voices.length === 0) {
    return <p className="text-slate-500 text-sm">Loading voices...</p>;
  }

  const handleTestVoice = () => {
    if (selectedVoiceURI) {
      testSpeak("Hello, this is a test of the selected voice.", selectedVoiceURI);
    }
  };

  return (
    <div>
      <label htmlFor="voice-select" className="block text-sm font-medium text-slate-700 text-left mb-1">
        Assistant's Voice
      </label>
      <div className="flex items-center gap-2">
        <select
          id="voice-select"
          value={selectedVoiceURI}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 block w-full pl-3 pr-10 py-2 text-base border-slate-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
        >
          {voices.map((voice) => (
            <option key={voice.voiceURI} value={voice.voiceURI}>
              {voice.name} ({voice.lang})
            </option>
          ))}
        </select>
        <button 
          onClick={handleTestVoice}
          className="p-2 rounded-md bg-slate-200 text-slate-600 hover:bg-slate-300"
          aria-label="Test selected voice"
        >
          <SpeakerIcon />
        </button>
      </div>
    </div>
  );
};
