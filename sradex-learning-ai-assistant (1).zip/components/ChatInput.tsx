
import React, { useState } from 'react';
import { SendIcon, MicrophoneIcon } from './Icons.tsx';
import { motion } from 'framer-motion';

interface ChatInputProps {
  onSendMessage: (input: string) => void;
  isLoading: boolean;
  onMicClick: () => void;
}

export const ChatInput: React.FC<ChatInputProps> = ({ 
  onSendMessage, 
  isLoading,
  onMicClick
}) => {
  const [input, setInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isLoading) {
      onSendMessage(input);
      setInput('');
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <form onSubmit={handleSubmit} className="flex items-center space-x-3">
        <div className="flex-1 relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a message or start a voice conversation..."
            aria-label="Chat input"
            className="w-full px-5 py-3 border border-slate-300/70 rounded-full focus:outline-none focus:ring-2 focus:ring-sky-500 transition duration-200 shadow-sm"
            disabled={isLoading}
          />
          <motion.button
            whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
            type="submit"
            disabled={isLoading || !input.trim()}
            aria-label="Send message"
            className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-sky-600 text-white disabled:bg-slate-400 disabled:cursor-not-allowed hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500 transition-colors"
          >
            <SendIcon />
          </motion.button>
        </div>
        <motion.button
          whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
          type="button"
          onClick={onMicClick}
          aria-label="Start live conversation"
          className="p-3.5 rounded-full text-white bg-sky-600 hover:bg-sky-700 transition-colors shadow-lg"
        >
          <div className="absolute inset-0 rounded-full bg-sky-500/50 animate-ping -z-10"></div>
          <MicrophoneIcon />
        </motion.button>
      </form>
    </div>
  );
};
