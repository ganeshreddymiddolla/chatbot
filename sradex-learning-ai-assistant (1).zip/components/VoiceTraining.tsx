
import React, { useState, useEffect } from 'react';
import { BotIcon, CheckCircleIcon, MicrophoneIcon } from './Icons.tsx';
import { motion, AnimatePresence } from 'framer-motion';
import { VoiceVisualizer } from './VoiceVisualizer.tsx';

interface VoiceTrainingProps {
  onTrainingComplete: () => void;
  startListening: () => void;
  stopListening: () => void;
  isListening: boolean;
  analyser: AnalyserNode | null;
  error: string | null;
}

const trainingSteps = [
  "Analyzing vocal pitch and tone...",
  "Mapping phonetic patterns...",
  "Generating unique voice profile...",
  "Finalizing personalization...",
];

const phraseToRecord = "Hello, I would like to personalize my AI assistant's voice.";

export const VoiceTraining: React.FC<VoiceTrainingProps> = ({ onTrainingComplete, startListening, stopListening, isListening, analyser, error }) => {
  const [step, setStep] = useState(0); // 0: Welcome, 1: Recording, 2: Processing, 3: Complete
  const [processingStep, setProcessingStep] = useState(0);
  const [isSimulatingRecording, setIsSimulatingRecording] = useState(false);

  const handleRecordClick = async () => {
    setIsSimulatingRecording(true);
    startListening(); // Use the centralized function
  };

  useEffect(() => {
    // If listening starts successfully (and we are in the recording simulation step),
    // run the simulation timer.
    if (isListening && isSimulatingRecording) {
      const timer = setTimeout(() => {
        stopListening();
        setIsSimulatingRecording(false);
        setStep(2);
      }, 4000); // Simulate recording for 4 seconds

      return () => clearTimeout(timer);
    }
  }, [isListening, isSimulatingRecording, stopListening]);

  useEffect(() => {
    let interval: number;
    if (step === 2) {
      interval = setInterval(() => {
        setProcessingStep(prev => {
          if (prev < trainingSteps.length - 1) {
            return prev + 1;
          }
          clearInterval(interval);
          setTimeout(() => setStep(3), 1000);
          return prev;
        });
      }, 1200);
    }
    if (step === 3) {
        setTimeout(() => {
            onTrainingComplete();
        }, 2000);
    }
    return () => clearInterval(interval);
  }, [step, onTrainingComplete]);

  const renderContent = () => {
    switch (step) {
      case 0:
        return (
          <motion.div key={0} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
            <h2 className="text-3xl font-bold text-slate-800">Voice Personalization</h2>
            <p className="text-slate-600 mt-3 max-w-sm mx-auto">To create a truly personal experience, we'll generate a unique voice profile for your assistant.</p>
            <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={() => setStep(1)} className="mt-8 w-full bg-sky-600 text-white font-bold py-3 px-4 rounded-lg shadow-lg hover:bg-sky-700 transition-colors">
              Begin Voice Cloning
            </motion.button>
          </motion.div>
        );
      case 1:
        return (
          <motion.div key={1} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
            <h2 className="text-3xl font-bold text-slate-800">Voice Sample Capture</h2>
            {isListening ? (
              <>
                <p className="text-slate-600 mt-3">Now analyzing... Speak clearly.</p>
                <div className="h-24 my-4 flex justify-center items-center">
                  <VoiceVisualizer analyser={analyser} isListening={isListening} isSpeaking={false} />
                </div>
              </>
            ) : (
              <>
                <p className="text-slate-600 mt-3">Click the button and say the following phrase:</p>
                <p className="text-lg font-semibold text-slate-700 my-4 p-4 bg-slate-100/80 rounded-lg border border-slate-200">"{phraseToRecord}"</p>
              </>
            )}
            <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={handleRecordClick} disabled={isListening} className="mt-4 w-full flex items-center justify-center gap-3 bg-sky-600 text-white font-bold py-3 px-4 rounded-lg shadow-lg hover:bg-sky-700 transition-colors disabled:bg-slate-400">
              {isListening ? (
                <>
                  <motion.div className="w-2.5 h-2.5 rounded-full bg-red-500" animate={{ scale: [1, 1.5, 1] }} transition={{ duration: 1, repeat: Infinity }}></motion.div>
                  <span>Analyzing...</span>
                </>
              ) : (
                <>
                  <MicrophoneIcon />
                  <span>Start Analysis</span>
                </>
              )}
            </motion.button>
            {error && !isListening && <p className="text-red-500 text-sm mt-4">{error}</p>}
          </motion.div>
        );
      case 2:
        return (
          <motion.div key={2} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
            <h2 className="text-3xl font-bold text-slate-800">Cloning Voice...</h2>
            <p className="text-slate-600 mt-3">This is a simulation of a complex voice cloning process.</p>
            <div className="mt-8 space-y-4 text-left">
                {trainingSteps.map((text, index) => (
                    <motion.div key={text} initial={{ opacity: 0 }} animate={{ opacity: processingStep >= index ? 1 : 0.3 }} transition={{ delay: index * 0.2 }} className="flex items-center gap-3">
                        {processingStep > index ? <CheckCircleIcon className="w-6 h-6 text-green-500 flex-shrink-0" /> : <div className="w-6 h-6 border-2 border-slate-300 border-t-sky-500 rounded-full animate-spin flex-shrink-0"></div>}
                        <span className={`transition-colors ${processingStep > index ? 'text-slate-500 line-through' : 'text-slate-700 font-medium'}`}>{text}</span>
                    </motion.div>
                ))}
            </div>
          </motion.div>
        );
      case 3:
        return (
            <motion.div key={3} initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }}>
                <CheckCircleIcon className="w-20 h-20 text-green-500 mx-auto" />
                <h2 className="text-3xl font-bold text-slate-800 mt-4">Voice Profile Created!</h2>
                <p className="text-slate-600 mt-3">Your AI assistant will now use your personalized voice. Starting the chat...</p>
            </motion.div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex flex-col h-screen items-center justify-center p-4 overflow-hidden">
        <div className="absolute inset-0 -z-10 h-full w-full bg-white bg-[linear-gradient(to_right,#f0f0f0_1px,transparent_1px),linear-gradient(to_bottom,#f0f0f0_1px,transparent_1px)] bg-[size:6rem_4rem]">
            <div className="absolute bottom-0 left-0 right-0 top-0 bg-[radial-gradient(circle_500px_at_50%_200px,#dbeafe,transparent)]"></div>
        </div>
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex justify-center mb-8">
            <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-xl border border-slate-200/80">
                <BotIcon className="w-8 h-8 text-sky-600" />
            </div>
        </motion.div>
        <div className="w-full max-w-lg">
            <div className="bg-white/60 backdrop-blur-xl rounded-2xl shadow-xl border border-slate-200/80 p-8 sm:p-12 text-center min-h-[350px] flex flex-col justify-center">
                <AnimatePresence mode="wait">
                    {renderContent()}
                </AnimatePresence>
            </div>
        </div>
    </div>
  );
};
