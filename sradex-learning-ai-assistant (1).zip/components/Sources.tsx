
import React from 'react';
import type { GroundingSource } from '../types.ts';
import { LinkIcon } from './Icons.tsx';

interface SourcesProps {
  sources: GroundingSource[];
}

export const Sources: React.FC<SourcesProps> = ({ sources }) => {
  if (!sources || sources.length === 0) {
    return null;
  }

  return (
    <div className="mt-3">
      <h4 className="text-xs font-semibold text-slate-500 mb-1">Sources:</h4>
      <div className="flex flex-wrap gap-2">
        {sources.map((source, index) => (
          <a
            key={index}
            href={source.uri}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs px-2 py-1 rounded-full transition-colors"
            title={source.title}
          >
            <LinkIcon />
            <span className="truncate max-w-[150px]">{new URL(source.uri).hostname}</span>
          </a>
        ))}
      </div>
    </div>
  );
};
