
import React from 'react';
import { VoiceSelector } from './VoiceSelector.tsx';
import { CloseIcon } from './Icons.tsx';
import { motion } from 'framer-motion';

interface SettingsModalProps {
  onClose: () => void;
  voices: SpeechSynthesisVoice[];
  selectedVoiceURI: string | null;
  onVoiceChange: (voiceURI: string) => void;
  testSpeak: (text: string, voiceURI: string) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ onClose, voices, selectedVoiceURI, onVoiceChange, testSpeak }) => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4" 
      onClick={onClose}
    >
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-2xl shadow-2xl w-full max-w-md p-6 relative" 
        onClick={(e) => e.stopPropagation()}
      >
        <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={onClose} className="absolute top-4 right-4 p-1 text-slate-500 hover:text-slate-800" aria-label="Close settings">
          <CloseIcon />
        </motion.button>
        <h2 className="text-xl font-bold text-slate-800 mb-6">Settings</h2>
        <div className="space-y-4">
          <VoiceSelector
            voices={voices}
            selectedVoiceURI={selectedVoiceURI || ''}
            onChange={onVoiceChange}
            testSpeak={testSpeak}
          />
        </div>
        <div className="mt-8 text-right">
            <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={onClose} className="bg-sky-600 text-white font-bold py-2 px-5 rounded-lg hover:bg-sky-700 transition-colors shadow-lg">
                Done
            </motion.button>
        </div>
      </motion.div>
    </motion.div>
  );
};
