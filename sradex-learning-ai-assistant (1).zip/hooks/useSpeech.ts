
import { useState, useEffect, useRef, useCallback } from 'react';

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

interface UseSpeechProps {
  onSpeechEnd: (transcript: string) => void;
}

export const useSpeech = ({ onSpeechEnd }: UseSpeechProps) => {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const silenceTimeoutRef = useRef<number | null>(null);

  const populateVoiceList = useCallback(() => {
    const newVoices = window.speechSynthesis.getVoices();
    setVoices(newVoices);
  }, []);

  const setupWebAudio = useCallback(async () => {
    if (audioContextRef.current && audioContextRef.current.state === "running") return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const audioContext = new (window.AudioContext || window.webkitAudioContext)();
      audioContextRef.current = audioContext;
      const newAnalyser = audioContext.createAnalyser();
      newAnalyser.fftSize = 512;
      setAnalyser(newAnalyser);
      mediaStreamSourceRef.current = audioContext.createMediaStreamSource(stream);
      mediaStreamSourceRef.current.connect(newAnalyser);
      setError(null); // Clear previous errors on success
    } catch (err) {
      console.error("Error setting up Web Audio:", err);
      if (err instanceof Error) {
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
          setError("Microphone access was denied. Please allow microphone access in your browser settings.");
        } else {
          setError(`Could not access microphone: ${err.message}`);
        }
      }
    }
  }, []);

  useEffect(() => {
    if (!SpeechRecognition) {
      setError('Speech Recognition API not supported in this browser.');
    } else {
        const recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = 'en-US';

        recognition.onstart = () => {
          setIsListening(true);
          setError(null);
        };

        recognition.onresult = (event: SpeechRecognitionEvent) => {
          if (silenceTimeoutRef.current) clearTimeout(silenceTimeoutRef.current);
          let finalTranscript = '';
          for (let i = 0; i < event.results.length; ++i) {
            finalTranscript += event.results[i][0].transcript;
          }
          
          if (event.results[event.results.length - 1].isFinal) {
             if (finalTranscript.trim()) {
                onSpeechEnd(finalTranscript.trim());
             }
             recognition.stop();
          } else {
             silenceTimeoutRef.current = window.setTimeout(() => {
                recognition.stop();
             }, 1500);
          }
        };

        recognition.onend = () => {
          setIsListening(false);
          if (silenceTimeoutRef.current) clearTimeout(silenceTimeoutRef.current);
        };
        
        recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
            console.error('Speech recognition error', event.error, event.message);
            setError(event.message || 'An unknown speech recognition error occurred.');
            setIsListening(false);
        };

        recognitionRef.current = recognition;
    }

    populateVoiceList();
    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = populateVoiceList;
    }

    return () => {
        window.speechSynthesis.cancel();
        audioContextRef.current?.close();
    };
  }, [populateVoiceList, onSpeechEnd]);

  const cancelSpeaking = useCallback(() => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  }, []);

  const startListening = useCallback(async () => {
    if (isSpeaking) cancelSpeaking();
    if (recognitionRef.current && !isListening) {
      await setupWebAudio();
      if (audioContextRef.current?.state === 'running') {
        recognitionRef.current.start();
      }
    }
  }, [isListening, isSpeaking, cancelSpeaking, setupWebAudio]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
    }
  }, [isListening]);

  const speak = useCallback((text: string, voiceURI: string | null) => {
    if (!window.speechSynthesis) return;
    cancelSpeaking();
    const utterance = new SpeechSynthesisUtterance(text);
    
    if (voiceURI) {
        const selectedVoice = voices.find(v => v.voiceURI === voiceURI);
        if (selectedVoice) utterance.voice = selectedVoice;
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  }, [voices, cancelSpeaking]);

  const testSpeak = useCallback((text: string, voiceURI: string) => {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const selectedVoice = voices.find(v => v.voiceURI === voiceURI);
    if (selectedVoice) {
        utterance.voice = selectedVoice;
    }
    window.speechSynthesis.speak(utterance);
  }, [voices]);

  return { isListening, isSpeaking, startListening, stopListening, speak, testSpeak, cancelSpeaking, voices, analyser, error };
};
