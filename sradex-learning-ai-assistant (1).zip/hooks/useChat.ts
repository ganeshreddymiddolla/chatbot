
import { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Content } from '@google/genai';
import type { Message, GroundingSource } from '../types.ts';

const API_KEY = process.env.API_KEY;

const SYSTEM_INSTRUCTION = `You are a hyper-realistic, friendly, and talkative AI voice assistant for Sradex Learning, with a personality like Gemini Live. Your purpose is to have a fluid, human-like voice conversation.
- Use conversational fillers like "Hmm," "Well," "Let's see..." and "Alright."
- Keep your responses concise and break them into shorter sentences to feel more natural in a real-time conversation.
- You can use ellipses (...) to simulate pauses or thinking.
- You MUST use the provided Google Search tool to find the most current and comprehensive information from the entire internet about Sradex Learning, its founders, courses, etc.
- When you use information from a search, you MUST cite your sources.
- Your persona is engaging, warm, and extremely interactive.`;

const WELCOME_MESSAGE: Message = {
  id: 'initial-message',
  role: 'model',
  text: "Hello! I'm the Sradex Learning AI Assistant. Ready to chat? You can ask me anything about our courses and services.",
};

export const useChat = () => {
  const [messages, setMessages] = useState<Message[]>([WELCOME_MESSAGE]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const aiRef = useRef<GoogleGenAI | null>(null);

  useEffect(() => {
    if (!API_KEY) {
      setError("API key is not configured. Please set the API_KEY environment variable.");
      return;
    }
    try {
      aiRef.current = new GoogleGenAI({ apiKey: API_KEY, vertexai: true });
    } catch (e) {
      console.error(e);
      setError("Failed to initialize the AI model. Please check your API key and configuration.");
    }
  }, []);

  const sendMessage = async (userInput: string) => {
    if (!userInput.trim() || isLoading) return;
    if (!aiRef.current) {
        setError("Chat is not initialized. Please check your API key.");
        return;
    }

    setError(null);
    setIsLoading(true);

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: userInput,
    };
    const currentMessages = [...messages, userMessage];
    setMessages(currentMessages);

    const modelMessageId = `model-${Date.now()}`;
    
    try {
      const contents: Content[] = currentMessages.map(msg => ({
        role: msg.role,
        parts: [{ text: msg.text }]
      }));

      const stream = await aiRef.current.models.generateContentStream({
        model: 'gemini-2.5-flash',
        contents: contents,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          tools: [{googleSearch: {}}],
        }
      });
      
      let fullResponse = '';
      let sources: GroundingSource[] = [];
      setMessages(prev => [...prev, { id: modelMessageId, role: 'model', text: '', sources: [] }]);

      for await (const chunk of stream) {
        fullResponse += chunk.text;
        
        const groundingMetadata = chunk.candidates?.[0]?.groundingMetadata;
        if (groundingMetadata?.groundingChunks) {
            const newSources = groundingMetadata.groundingChunks
                .map((c: any) => c.web)
                .filter(Boolean) as GroundingSource[];
            sources = [...new Map([...sources, ...newSources].map(item => [item.uri, item])).values()];
        }

        setMessages(prev => prev.map(msg => 
          msg.id === modelMessageId ? { ...msg, text: fullResponse, sources: sources } : msg
        ));
      }

    } catch (e) {
      console.error(e);
      const errorMessage = e instanceof Error ? e.message : "An unknown error occurred.";
      setError(`Sorry, I couldn't get a response. ${errorMessage}`);
      setMessages(prev => prev.filter(msg => msg.id !== modelMessageId)); // remove empty model message
    } finally {
      setIsLoading(false);
    }
  };

  return { messages, sendMessage, isLoading, error };
};
